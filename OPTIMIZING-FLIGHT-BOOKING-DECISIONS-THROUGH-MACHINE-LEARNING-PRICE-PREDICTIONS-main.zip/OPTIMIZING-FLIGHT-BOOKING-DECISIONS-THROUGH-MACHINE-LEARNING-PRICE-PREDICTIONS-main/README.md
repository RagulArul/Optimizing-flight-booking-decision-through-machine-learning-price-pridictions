# OPTIMIZING-FLIGHT-BOOKING-DECISIONS-THROUGH-MACHINE-LEARNING-PRICE-PREDICTIONS

video demonstration--https://drive.google.com/file/d/1SfH6Lh9Gma_9_nqySu8DJL-KXI9voIbb/view?usp=share_link
